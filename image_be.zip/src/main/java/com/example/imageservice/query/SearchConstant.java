package com.example.imageservice.query;

public class SearchConstant {

    public static final String OBJECT_NULL = "#NULL#";
    public static final String OBJECT_NOT_NULL = "#NOTNULL#";
    public static final String NUMBER_NULL = "-99999";
}