package com.example.imageservice.service;

import com.example.imageservice.entity.ImageCard;
import org.springframework.web.multipart.MultipartFile;

public interface ImageCardService extends BaseService<ImageCard> {
//    public String upload(MultipartFile file, Long id);
}
