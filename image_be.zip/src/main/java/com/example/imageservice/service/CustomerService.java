package com.example.imageservice.service;

import com.example.imageservice.entity.Customer;
import com.example.imageservice.model.response.BaseResponse;
import org.springframework.web.multipart.MultipartFile;

public interface CustomerService extends BaseService<Customer> {
//    public BaseResponse customCreate(MultipartFile file, Customer customer);
}
