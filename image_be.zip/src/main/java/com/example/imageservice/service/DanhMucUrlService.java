package com.example.imageservice.service;

import com.example.imageservice.entity.DanhMucUrl;

public interface DanhMucUrlService extends BaseService<DanhMucUrl>{
}
