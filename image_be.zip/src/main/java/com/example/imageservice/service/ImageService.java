package com.example.imageservice.service;

import com.example.imageservice.entity.Image;

public interface ImageService extends BaseService<Image>{
}
