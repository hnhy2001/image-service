package com.example.imageservice.repository;

import com.example.imageservice.entity.DanhMucUrl;

public interface DanhMucUrlRepository extends BaseRepository<DanhMucUrl> {
}
