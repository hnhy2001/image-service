package com.example.imageservice.repository;

import com.example.imageservice.entity.Customer;

public interface CustomerRepository extends BaseRepository<Customer> {
}
