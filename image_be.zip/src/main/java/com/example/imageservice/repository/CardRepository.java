package com.example.imageservice.repository;

import com.example.imageservice.entity.Card;

public interface CardRepository extends BaseRepository<Card> {
}
