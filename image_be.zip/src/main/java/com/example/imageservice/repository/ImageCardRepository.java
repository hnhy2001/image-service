package com.example.imageservice.repository;

import com.example.imageservice.entity.ImageCard;

public interface ImageCardRepository extends BaseRepository<ImageCard> {
}
