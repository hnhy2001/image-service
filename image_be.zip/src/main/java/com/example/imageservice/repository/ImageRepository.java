package com.example.imageservice.repository;

import com.example.imageservice.entity.Image;

public interface ImageRepository extends BaseRepository<Image> {
}
